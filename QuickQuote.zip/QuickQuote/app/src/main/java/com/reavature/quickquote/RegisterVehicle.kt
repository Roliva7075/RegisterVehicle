package com.reavature.quickquote

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RegisterVehicle : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_vehicle)
    }
}